#!/bin/sh

polybar-msg hook network 1 >/dev/null 2>&1
exit 0
