#!/bin/sh
# send='sudo -u user1 DISPLAY=:0 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus notify-send'
 
router_mac="$(ip neigh | grep router | cut -d' ' -f5 | uniq)" 
home_router_mac="54:67:51:84:be:42" 
# $send "interface $1 is $2, router mac is $router_mac"

if [ "$router_mac" = "$home_router_mac" ]
then
    # home
else
    # nohome
fi
