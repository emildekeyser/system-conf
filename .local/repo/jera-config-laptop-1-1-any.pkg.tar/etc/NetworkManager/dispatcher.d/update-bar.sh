#!/bin/sh

polybar-msg hook usb-wlan 1
exit 0
