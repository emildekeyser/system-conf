#!/bin/sh

polybar-msg hook network 1
exit 0
